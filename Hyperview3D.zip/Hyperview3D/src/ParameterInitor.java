/**
*@author Kedar Bhumkar
*@version 1.0
*/

package Hyperview3D;


import java.io.*;
import java.util.*;

/*
		This class reads properties.txt and inits values which affect the viewing
		Make changes to properties.txt to customize your view .
*/

class ParameterInitor
{

	void initializeValues()
	{
				String tokens[] = new String[20];

				 try
			     {
						StringTokenizer st;
						String line ;

						byte b = 0;

						BufferedReader  br1 = new BufferedReader( new FileReader("properties.txt") ) ;

						//read the file
					    while( (line = br1.readLine() )!=null )
						   {
								//Split strings like " Token=value" so that it returns Token and Value as strings
								st =  new StringTokenizer( line ,"=");
								if( st.hasMoreElements())
									{
										st.nextToken();
										//Store the value portion
										tokens[b++] = st.nextToken();
								     }

						    }

				}
				catch( IOException ioe )
				{

					  ioe.printStackTrace();


				}


				 copyTokens( tokens);

	}


	//initialize different values

    private void copyTokens( String tokens[] )
      {

			/*
				More the slices, angle divs more detailed
				the hyperboloid.

				!!!!!DO NOT ALTER THE Z-VALUE AS IT'S CALCULATED FROM
				DR.DUNHAM'S PROGRAM. THIS PARTICULAR Z-VALUE MAKES
				IT POSSIBLE FOR THE SAMPLE IMAGE TO BE MAPPED PERFECTLY
				ONTO THE 	3D HYPERBOLOID WITHOUT ANY DISTORTION.
			*/

			//Affects how much the hyperboloid is scaled
			Hyperboloid.setSCALE_FACTOR( new    Float(tokens[0].trim()) );

			//No of slices
			Hyperboloid.setNO_OF_SLICES( new Integer(tokens[1].trim()) );

			//No of angle divs
			Hyperboloid.setNO_OF_ANG_DIVS( new Integer(tokens[2].trim()) );

			//The z-value or ht
			Hyperboloid.setZ_HEIGHT(new Double(tokens[3].trim()) ) ;

			//Field of view
			ModelViewer.FIELD_OF_VIEW					=  new Double(tokens[4].trim());

			//Screen aspect ratio. Don't change this 3D shape will get distorted
			ModelViewer.ASPECT_RATIO					=  new Double(tokens[5].trim()) ;

			//Front clipping plane distance from user eye
			ModelViewer.FCP_DIST							=  new Double(tokens[6].trim()) ;

			//Back clipping plane distance from user eye
			ModelViewer.BCP_DIST							=  new Double(tokens[7].trim()) ;

			//User eye's X, Y, Z
			ModelViewer.OBSERVER_POSITION_X	=  new Double(tokens[8].trim()) ;
			ModelViewer.OBSERVER_POSITION_Y	=  new Double(tokens[9].trim()) ;
			ModelViewer.OBSERVER_POSITION_Z    =  new Double(tokens[10].trim()) ;

			//This defines the orientation of the mapped image.
			ModelViewer.VIEW_X_VALUE             		=  new Double(tokens[11].trim()) ;
			ModelViewer.VIEW_Y_VALUE             		=  new Double(tokens[12].trim()) ;
			ModelViewer.VIEW_Z_VALUE             		=  new Double(tokens[13].trim()) ;

			/*
				These values are only used in Parallel Projection and hence only in the Gans model.
				For parallel projection a rectangular parallelopiped is defined. These values define it.

			*/
			ModelViewer.LEFT_EDGE       		      		=  new Double(tokens[14].trim()) ;
			ModelViewer.RIGHT_EDGE     	        		=  new Double(tokens[15].trim()) ;
			ModelViewer.BOTTOM_EDGE 	           		=  new Double(tokens[16].trim()) ;
			ModelViewer.TOP_EDGE         		     	=  new Double(tokens[17].trim()) ;
			ModelViewer.NEAR_DIST        		      		=  new Double(tokens[18].trim()) ;
			ModelViewer.FAR_DIST           			   	=  new Double(tokens[19].trim()) ;



	  }


}