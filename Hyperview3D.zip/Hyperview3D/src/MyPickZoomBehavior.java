package Hyperview3D;

import java.util.Enumeration;
import javax.media.j3d.*;
import javax.media.j3d.Group.*;
import com.sun.j3d.utils.behaviors.vp.OrbitBehavior;
import com.sun.j3d.utils.universe.*;
import com.sun.j3d.utils.picking.behaviors.PickZoomBehavior;
import com.sun.j3d.utils.picking.behaviors.PickingCallback;
import javax.vecmath.*;


/*

   This class is responsible for zooming on mouse right click.
   Functionally it is similar to MyPickTranslateBehavior.
   See that class for more comments

*/



public class MyPickZoomBehavior extends PickZoomBehavior implements PickingCallback  {

	TransformGroup tg;
	Hyperboloid hpg;
	static double d1,d2,d3;
	PositionCoord posCoord;



	public MyPickZoomBehavior(BranchGroup bg , Canvas3D c3D , Bounds bounds , TransformGroup tg , Hyperboloid hpg , 	PositionCoord posCoord)
	{
			super( bg , c3D , bounds);
			this.tg = tg;
			this.hpg = hpg;
			this.posCoord = posCoord;


	}


public   void transformChanged(int type,  Transform3D t3d)
   {

	   System.out.println( " Inside tC T3d =" + (d2++) );

		Transform3D t3D = new Transform3D();
		tg.getTransform(t3D);

		hpg.setVPTransform( (byte)0 , t3D );

		posCoord.findXYZ( t3D );

		hpg.setObsX( posCoord.getX() );
		hpg.setObsY( posCoord.getY() );
		hpg.setObsZ( posCoord.getZ() );

		ControlPanel.setSliderPos( (int)posCoord.getZ() );
   }


public   void transformChanged(int type,  TransformGroup tgx)
   {
	   System.out.println( " Inside tC T3d =" + (d2++) );
   }




}