package Hyperview3D;

import javax.media.j3d.*;
import java.awt.GraphicsConfiguration;
import java.awt.Color;
import java.text.DecimalFormat;



public class MyCanvas3D extends Canvas3D
{

		J3DGraphics2D drawg2d;
		PositionCoord posCoord;
		DecimalFormat numberFormatter;
		Color clr;


		MyCanvas3D( GraphicsConfiguration config, PositionCoord posCoord , Color clr)
		{

			   super( config );
			   this.clr = clr;
			   this.posCoord 	= posCoord;
			   numberFormatter = new DecimalFormat("##0.00");

		}

		public void postRender()
		{

			super.postRender();
			//System.out.println("Inside Post Render");
			drawg2d = this.getGraphics2D();
			drawg2d.setColor( clr);
			drawg2d.drawString(" X = " + numberFormatter.format(posCoord.getX())  , 0,10);
			drawg2d.drawString(" Y = " + numberFormatter.format(posCoord.getY())  , 100,10);
			drawg2d.drawString(" Z = " + numberFormatter.format(posCoord.getZ())  , 200,10);
			drawg2d.setColor( new Color( 32,178,170)   );
			drawg2d.drawString(" Proj Type - ",300,10  );
			drawg2d.setColor( new Color(	255,182,193) );
			drawg2d.drawString(posCoord.getProjType() , 365,10 );
			drawg2d.flush( true ) ;

		}






}