package Hyperview3D;

import java.applet.Applet;
import java.awt.BorderLayout;
import java.awt.Frame;
import java.awt.event.*;
import java.awt.GraphicsConfiguration;
import com.sun.j3d.utils.applet.MainFrame;
import com.sun.j3d.utils.universe.*;
import com.sun.j3d.utils.geometry.ColorCube;
import javax.media.j3d.*;
import javax.vecmath.*;


/*

This class is responsible for the animation. Animation is only done in the Model View.
for the 3D Hyperboloid  and the Avatar object*
Pls see for more details :
http://java.sun.com/products/java-media/3D/forDevelopers/J3D_1_3_API/j3dapi/javax/media/j3d/RotPosPathInterpolator.html

*/



public class Animation
{

	TransformGroup target;
	BranchGroup objRoot;
	RotPosPathInterpolator rotPosPath;
	byte cID;
	Hyperboloid hpg;

	//Constructor
	public Animation( TransformGroup target , BranchGroup objRoot , byte cID , Hyperboloid hpg)
	{

			this.target     = target;
			this.objRoot  = objRoot;
			this.cID         =  cID;
			this.hpg        =  hpg;

	}

public void startAnimation()
{


			Alpha alpha = new Alpha(-1, 10000);
			Transform3D axisOfRotPos = new Transform3D();

			//These values define the smoothness of the animation
			float[] knots = { 0.0f, 0.05f, 0.1f, 0.15f, 0.2f, 0.25f, 0.30f, 0.35f, 0.4f, 0.45f, 0.5f, 0.55f, 0.6f, 0.65f, 0.7f, 0.75f, 0.8f, 0.85f, 0.9f, 1.0f  };


			Quat4f[] quats = new Quat4f[20];

			Point3f[] positions = new Point3f[20];

			//Axis around which to animate
			AxisAngle4f axis = new AxisAngle4f(0.0f,0.0f,-1.0f,0.0f);
			axisOfRotPos.set(axis);

			quats[0] = new Quat4f(0.0f, -1.0f, 0.0f, 0.0f);
			quats[1] = new Quat4f(0.0f, -1.0f, 0.0f, 0.0f);
			quats[2] = new Quat4f(0.0f, -1.0f, 0.0f, 0.0f);
			quats[3] = new Quat4f(0.0f, -1.0f, 0.0f, 0.0f);
			quats[4] = new Quat4f(0.0f, -1.0f, 0.0f, 0.0f);
			quats[5] = new Quat4f(0.0f, -1.0f, 0.0f, 0.0f);
			quats[6] = new Quat4f(0.0f, -1.0f, 0.0f, 0.0f);
			quats[7] = new Quat4f(0.0f, -1.0f, 0.0f, 0.0f);
			quats[8] = new Quat4f(0.0f, -1.0f, 0.0f, 0.0f);
			quats[9] = new Quat4f(0.0f, -1.0f, 0.0f, 0.0f);

			quats[10] = new Quat4f(0.0f, -1.0f, 0.0f, 0.0f);
			quats[11] = new Quat4f(0.0f, -1.0f, 0.0f, 0.0f);
			quats[12] = new Quat4f(0.0f, -1.0f, 0.0f, 0.0f);
			quats[13] = new Quat4f(0.0f, -1.0f, 0.0f, 0.0f);
			quats[14] = new Quat4f(0.0f, -1.0f, 0.0f, 0.0f);
			quats[15] = new Quat4f(0.0f, -1.0f, 0.0f, 0.0f);
			quats[16] = new Quat4f(0.0f, -1.0f, 0.0f, 0.0f);
			quats[17] = new Quat4f(0.0f, -1.0f, 0.0f, 0.0f);
			quats[18] = new Quat4f(0.0f, -1.0f, 0.0f, 0.0f);
			quats[19] = new Quat4f(0.0f, -1.0f, 0.0f, 0.0f);

			//Path to move the object

			positions[0]= new Point3f( 0.0f, 0.0f, 0.00f);
			positions[1]= new Point3f( 0.0f, 0.0f, -0.00f);
			positions[2]= new Point3f( 0.0f, 0.0f, -0.10f);

			positions[3]= new Point3f( 0.0f, 0.0f, -0.20f);
			positions[4]= new Point3f( 0.0f, 0.0f, -0.30f);
			positions[5]= new Point3f( 0.0f, 0.0f, -0.40f);
			positions[6]= new Point3f( 0.0f, 0.0f, -0.60f);
			positions[7]= new Point3f( 0.0f, 0.0f, -0.82f);
			positions[8]= new Point3f( 0.0f, 0.0f, -0.93f);
			positions[9]= new Point3f( 0.0f, 0.0f, -1.00f);

			positions[19]= new Point3f( 0.0f, 0.0f, 0.00f);
			positions[18]= new Point3f( 0.0f, 0.0f, -0.00f);
			positions[17]= new Point3f( 0.0f, 0.0f, -0.10f);
			positions[16]= new Point3f( 0.0f, 0.0f, -0.20f);
			positions[15]= new Point3f( 0.0f, 0.0f, -0.30f);
			positions[14]= new Point3f( 0.0f, 0.0f, -0.40f);
			positions[13]= new Point3f( 0.0f, 0.0f, -0.60f);
			positions[12]= new Point3f( 0.0f, 0.0f, -0.82f);
			positions[11]= new Point3f( 0.0f, 0.0f, -0.93f);
			positions[10]= new Point3f( 0.0f, 0.0f, -1.00f);


			rotPosPath = new MyRotPosPathInterpolator(alpha, target, axisOfRotPos, knots, quats, positions , cID , hpg);
			rotPosPath.setSchedulingBounds(new BoundingSphere());
			objRoot.addChild(rotPosPath);



}

void setEnable( boolean blnEnable)
{

			rotPosPath.setEnable( blnEnable );

}



}





