package Hyperview3D;

import javax.swing.*;



import java.awt.event.*;

import java.beans.PropertyVetoException;



class MyWindowStateListener implements WindowStateListener
{

    int parFrSizeX, parFrSizeY, sqrparFrSizeX,sqrparFrSizeY,vwSize ;
    JFrame jfParent;
    static boolean blnMaxed = true;
    JInternalFrame jf1 , jf2;
    static byte evenCounter = 0;
	JDesktopPane desktop;


	MyWindowStateListener(int parFrSizeX, int parFrSizeY, int sqrparFrSizeX,int sqrparFrSizeY , JFrame jfParent, JInternalFrame jf1,int vwSize,JDesktopPane desktop)
	{

		this.parFrSizeX = parFrSizeX ;
		this.parFrSizeY = parFrSizeY ;
		this.sqrparFrSizeX = sqrparFrSizeX;
		this.sqrparFrSizeY = sqrparFrSizeY;
		this.jfParent = jfParent;
		this.jf1 = jf1;

		this.vwSize = vwSize;
		this.desktop = desktop;



	}


	public void 	windowStateChanged(WindowEvent e)
	{




	if(evenCounter%2 == 0)
	{

		jf2 = desktop.getSelectedFrame();
		if( jf2 == null)
		  jf2 = jf1;


		if( blnMaxed )
		 {
						System.out.println("Maxing");

						try
							{
								jf2.setMaximum( true );
							}
							catch( PropertyVetoException pve ) {}

						jfParent.setSize(sqrparFrSizeX, sqrparFrSizeY);

		 }
		else
		 {
						System.out.println("Minimizing");

						try
							{
								jf2.setMaximum( false );
							}
							catch( PropertyVetoException pve ) {}


						jfParent.setSize(parFrSizeX, parFrSizeY);


		 }

		 blnMaxed=!blnMaxed;
	 }
     else
        System.out.println("evenCounter =" + evenCounter);

    evenCounter++;

	}

}