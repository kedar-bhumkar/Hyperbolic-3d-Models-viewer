package Hyperview3D;

import java.awt.Color;



import javax.media.j3d.*;
import javax.media.j3d.Group.*;

import javax.vecmath.*;

/*
		This class creates the 3 co-ordinate axes X,Y,Z
*/


class Axis
{

	/*

		c01, c23 ... etc are all line colors

	*/

	TransformGroup createAxis( float SCALE_FACTOR , float lineSize,float c01 , float c23 , float c45 , float c67 , float c89 , float c1011)
	{

		  TransformGroup tg  = new  TransformGroup();

	      Transform3D t3dScale = new Transform3D(  );
		  t3dScale.setScale( SCALE_FACTOR) ;
		  tg.setTransform( t3dScale );

		  //In built primitive for drawing line.
		  LineArray   la = new LineArray((int)( 6+12*lineSize), LineArray.COORDINATES | LineArray.COLOR_3 ) ;
		  Point3f[] pts = new Point3f[(int)( 6+12*lineSize)];

		  //Point Co-ordinates
		  pts[0] = new Point3f( 0.0f , 0.0f , 0.0f );
		  pts[1] = new Point3f( lineSize , 0.0f , 0.0f);
		  pts[2] = new Point3f( 0.0f , 0.0f , 0.0f );
		  pts[3] = new Point3f( 0.0f , lineSize , 0.0f);
		  pts[4] = new Point3f( 0.0f , 0.0f , 0.0f );
		  pts[5] = new Point3f( 0.0f , 0.0f , lineSize);

		  //Red, Blue, Green colors
		  Color3f clrs[] = new Color3f[(int)( 6+12*lineSize)];
		  clrs[0] = new Color3f( c01 , 0.0f , 0.0f );
		  clrs[1] = new Color3f( c01 , 0.0f , 0.0f );
		  clrs[2] = new Color3f( 0.0f , c23, 0.0f );
		  clrs[3] = new Color3f( 0.0f , c23 , 0.0f );
		  clrs[4] = new Color3f( 0.0f , 0.0f , c45 );
		  clrs[5] = new Color3f( 0.0f , 0.0f , c45 );

		  int cnt = 6;
		  boolean blnOnce = true;

		 /*
		   This draws lines on and off for every 0.50 length giving the following
		   layout ( - - - - - )
		  */

		  for( float i = 0.0f ; i<lineSize ;i+=0.5f)
		  {

				pts[ cnt ] = new Point3f( -i , 0.0f , 0.0f );

				if(blnOnce)
					clrs[cnt++] = new Color3f( c67 , 0.0f , 0.0f );
				else
					clrs[cnt++] = new Color3f( 0.0f , 0.0f , 0.0f );

				pts[ cnt ] = new Point3f( -(i+0.25f) , 0.0f , 0.0f );

				if(blnOnce)
					clrs[cnt++] = new Color3f( c67 , 0.0f , 0.0f );
				else
					clrs[cnt++] = new Color3f( 0.0f , 0.0f , 0.0f );

				pts[ cnt ] = new Point3f( 0.0f,  -i,  0.0f );

				if(blnOnce)
					clrs[cnt++] = new Color3f( 0.0f , c89 , 0.0f );
				else
					clrs[cnt++] = new Color3f( 0.0f , 0.0f , 0.0f );

				pts[ cnt ] = new Point3f( 0.0f,-(i+0.25f) , 0.0f );

				if(blnOnce)
					clrs[cnt++] = new Color3f( 0.0f , c89 , 0.0f );
				else
					clrs[cnt++] = new Color3f( 0.0f , 0.0f , 0.0f );

				pts[ cnt ] = new Point3f(0.0f, 0.0f,  -i );


				if(blnOnce)
					clrs[cnt++] = new Color3f( 0.0f , 0.0f , c1011 );
				else
					clrs[cnt++] = new Color3f( 0.0f , 0.0f , 0.0f );

				pts[ cnt ] = new Point3f(0.0f , 0.0f, -(i+0.25f));

				if(blnOnce)
					clrs[cnt++] = new Color3f( 0.0f , 0.0f , c1011 );
				else
					clrs[cnt++] = new Color3f( 0.0f , 0.0f , 0.0f );

					blnOnce =!blnOnce;

			}

			  la.setCoordinates( 0 , pts );
			  la.setColors( 0 , clrs );

			  tg.addChild( new  Shape3D(la) );

			  return tg;
		}
}