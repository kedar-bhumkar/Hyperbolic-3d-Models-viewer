package Hyperview3D;

import javax.media.j3d.View;
import javax.media.j3d.Transform3D;
import javax.media.j3d.TransformGroup;
import javax.vecmath.Point3d;
import javax.vecmath.Vector3d;
import com.sun.j3d.utils.picking.PickCanvas;


import com.sun.j3d.utils.universe.*;

/**

This class is responsible for actual showing the different models in the 2 screens.
The camera setting is defined here

Pls refer  -  http://download.java.net/media/java3d/javadoc/1.4.0/javax/media/j3d/doc-files/ViewModel.html
for moredetails on "Java3D camera and viewing"

*/
class ModelViewer
{
		/*
		   Default values. Overridden by the file read feom ParameterInitor.java
		   Pls refer to ParameterInitor.java for a more detailed explanation
		*/

		//for FrameID = 0
		static double  VIEW_X_VALUE = 0.6;
		static double  VIEW_Y_VALUE = 0.0;
		static double  VIEW_Z_VALUE = 0.0;

		//for FrameID = 1
		static double  SECOND_VIEW_X_VALUE = -3.0;
		static double  SECOND_VIEW_Y_VALUE =   0.0;
		static double  SECOND_VIEW_Z_VALUE =   0.0;

		//for FrameID = 0
		static double  OBSERVER_POSITION_X = 0.0;
		static double  OBSERVER_POSITION_Y = 0.0;
		static double  OBSERVER_POSITION_Z = 0.0;

		//for FrameID = 1
		static double  SECOND_OBSERVER_POSITION_X =  -4.0;
		static double  SECOND_OBSERVER_POSITION_Y =    0.0;
		static double  SECOND_OBSERVER_POSITION_Z =    0.0;

		//Defines the edges of a rectangular parallelopipe
		static double LEFT_EDGE			=	-3.3;
		static double RIGHT_EDGE			=	 3.3;
		static double BOTTOM_EDGE     =-	 3.3;
		static double TOP_EDGE				=	 3.3;
		static double NEAR_DIST			=	 2;
		static double FAR_DIST				=	 300;

		static double FIELD_OF_VIEW	= Math.PI/2 ;
		static double ASPECT_RATIO	=1.6;
		static double FCP_DIST	=1.0;
		static double BCP_DIST	=3000.0f;

		// Required for 2 views.
		private MultiUniverse u;

		// 2 transform grps required for 2 views.
		private TransformGroup vpTG[] = new TransformGroup[Hyperboloid.noOfViews];

		// Reference to the 3D hyperboloid
		Hyperboloid hpg;

		//Flag to make decisions based on Gans(Parallel) and non-Gans model( Perspective)
		private boolean blnGansModel = false;


		//Constructor
		ModelViewer(MultiUniverse u , Hyperboloid hpg)
		{


				  this.u 	  =  u;
				  this.hpg =  hpg;

				// Store the 2 viewPlatforms obtained from the MultiUniverse object
				  for( byte cID = 0 ; cID < Hyperboloid.noOfViews ; cID++)
					vpTG[cID] = u.getViewingPlatform(cID).getViewPlatformTransform();


				//Initialize the different static values.
				 ParameterInitor paraInit = new ParameterInitor( );
				 paraInit.initializeValues();
		}



		//Written which model is currently shown

		 boolean getCurrentModel()
		 {

				return blnGansModel;


		 }


		 /*
		   This method displays the Klein as well as the Poincare model
		   for the SIDE VIEW ONLY.

		   It sets up the necessary camera settings to view these models.
		*/
		void	klienModel(View  vw , TransformGroup tgParent)
		{
				//Enable the camera
				vw.setCompatibilityModeEnable( true );

				//Enables PERSPECTIVE projection
				vw.setProjectionPolicy(vw.PERSPECTIVE_PROJECTION );
				Transform3D t1 = new Transform3D( );

				//This creates the conical view frustrum of perspective projection
				t1.perspective( FIELD_OF_VIEW , ASPECT_RATIO , FCP_DIST , BCP_DIST);
				vw.setLeftProjection( t1 );

				/*
				   This method takes an eye position, a position to look at, and an up vector and alter the view.
					This simulates movement of the users eye.
				*/
				t1.lookAt( new Point3d(OBSERVER_POSITION_X,OBSERVER_POSITION_Y, OBSERVER_POSITION_Z ) ,new Point3d(0,0,1.0f),new Vector3d(SECOND_VIEW_X_VALUE,SECOND_VIEW_Y_VALUE,SECOND_VIEW_Z_VALUE) );
				t1.invert();  														 //  If disabled apparently has no effect

				//Set the Avatar's transform
				Hyperboloid.setvpAVTTransform(t1);

				//Set the viewPlatform transform in Side viw
				vpTG[0].setTransform(t1);

				// Update displayed text
				hpg.posCoord[0].setProjType("Perspective.");
				hpg.posCoord[0].setX( OBSERVER_POSITION_X  );
				hpg.posCoord[0].setY( OBSERVER_POSITION_Y  );
				hpg.posCoord[0].setZ( OBSERVER_POSITION_Z  );

				//Change slider pos
				ControlPanel.setSliderPos( (int)OBSERVER_POSITION_Z );
				blnGansModel = false;
		}

		 /*
		   This method displays the Gans model  for the SIDE VIEW ONLY.
		   It sets up the necessary camera settings to view these models.
		*/

		void	gansModel( View  vw,TransformGroup tgParent)
		{


				vw.setCompatibilityModeEnable( true );

				vw.setProjectionPolicy(vw.PARALLEL_PROJECTION );

				Transform3D t1 = new Transform3D( );



				//Sets up the rectangular parallelopipe  as the view frustrum
				t1.ortho( LEFT_EDGE, RIGHT_EDGE,  BOTTOM_EDGE/ASPECT_RATIO,TOP_EDGE/ASPECT_RATIO,NEAR_DIST,FAR_DIST);


			   vw.setLeftProjection( t1 );
				t1.lookAt( new Point3d(OBSERVER_POSITION_X,OBSERVER_POSITION_Y, OBSERVER_POSITION_Z ) ,new Point3d(0,0,1.0f),new Vector3d(SECOND_VIEW_X_VALUE,SECOND_VIEW_Y_VALUE,SECOND_VIEW_Z_VALUE) );


				t1.invert();


				Hyperboloid.setvpAVTTransform(t1);

				vpTG[0].setTransform(t1);

				hpg.posCoord[0].setProjType("Parallel.");
				hpg.posCoord[0].setX(  OBSERVER_POSITION_X );
				hpg.posCoord[0].setY(  OBSERVER_POSITION_Y  );
				hpg.posCoord[0].setZ(  OBSERVER_POSITION_Z );

				blnGansModel = true;


		}

		 /*
		   This method displays the Klein as well as the Poincare model
		   for the MODEL VIEW ONLY.

		   FrameID = 1

		  It sets up the necessary camera settings to view these models.
		*/

		void isometricKlienModel(View  vw ,  TransformGroup tgParent)
		{

				vw.setCompatibilityModeEnable( true );


				vw.setProjectionPolicy(vw.PERSPECTIVE_PROJECTION );

				Transform3D tIS = new Transform3D( );

				FIELD_OF_VIEW = Math.PI/2;
				tIS .perspective( FIELD_OF_VIEW , ASPECT_RATIO , FCP_DIST , BCP_DIST);



			   vw.setLeftProjection( tIS  );

				tIS.lookAt( new Point3d(SECOND_OBSERVER_POSITION_X,SECOND_OBSERVER_POSITION_Y, SECOND_OBSERVER_POSITION_Z ) ,new Point3d(0,0,1.0f),new Vector3d(SECOND_VIEW_X_VALUE,SECOND_VIEW_Y_VALUE,SECOND_VIEW_Z_VALUE) );
				tIS.invert();

				vpTG[1].setTransform(tIS);

				hpg.posCoord[1].setProjType("Perspective.");
				hpg.posCoord[1].setX( SECOND_OBSERVER_POSITION_X  );
				hpg.posCoord[1].setY( SECOND_OBSERVER_POSITION_Y  );
				hpg.posCoord[1].setZ( SECOND_OBSERVER_POSITION_Z  );


		}


		 /*
		   This method displays the Gans model  for the MODEL VIEW ONLY.
		   It sets up the necessary camera settings to view these models.
		*/
		void isometricGansModel(View  vw ,  TransformGroup tgParent)
		{

				vw.setCompatibilityModeEnable( true );

				vw.setProjectionPolicy(vw.PARALLEL_PROJECTION );

				Transform3D tIS = new Transform3D( );

				tIS.ortho( LEFT_EDGE, RIGHT_EDGE,  BOTTOM_EDGE/ASPECT_RATIO,TOP_EDGE/ASPECT_RATIO,NEAR_DIST,FAR_DIST);


			   vw.setLeftProjection( tIS );

				tIS.lookAt( new Point3d(0,0,-1) ,new Point3d(0,0,1),new Vector3d(SECOND_VIEW_X_VALUE,SECOND_VIEW_Y_VALUE,SECOND_VIEW_Z_VALUE) );
				tIS.invert();

				vpTG[1].setTransform(tIS);
				hpg.posCoord[1].setProjType("Parallel.");
				hpg.posCoord[1].setX(  0 );
				hpg.posCoord[1].setY(  0  );
				hpg.posCoord[1].setZ( -1 );

		 }

}