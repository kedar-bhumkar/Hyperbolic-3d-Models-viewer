package Hyperview3D;

import java.util.Enumeration;
import javax.media.j3d.*;
import javax.media.j3d.Group.*;
import com.sun.j3d.utils.behaviors.vp.OrbitBehavior;


public class MyOrbitBehavior extends OrbitBehavior {

	TransformGroup tg;
	byte cID;
	PositionCoord posCoord;



	public MyOrbitBehavior(Canvas3D c3D , TransformGroup tg , byte cID , PositionCoord posCoord )
	{
			super( c3D );

			this.tg = tg;
			this.cID = cID;
			this.posCoord = posCoord;


	}





	public void processStimulus( Enumeration criteria )
	{
		// Do something on a wakeup

		Transform3D t3D = new Transform3D();
 		tg.getTransform(t3D);


		if ( cID == 0 )
		{
		   t3D.invert();
		   Hyperboloid.setvpAVTTransform( t3D );

	   }


		posCoord.findXYZ( t3D );

		super.processStimulus( criteria );



   }
}