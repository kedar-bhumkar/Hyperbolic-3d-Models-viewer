package Hyperview3D;

import java.util.Enumeration;
import javax.media.j3d.*;
import javax.media.j3d.Group.*;
import com.sun.j3d.utils.universe.*;
import javax.media.j3d.*;

import javax.vecmath.*;




public class MyRotPosPathInterpolator extends RotPosPathInterpolator
{

		Alpha alpha;
		TransformGroup target;
		Transform3D axisOfRotPos;
		float[] knots;
		Quat4f[] quats;
		Point3f[] positions;
		byte cID;
		Hyperboloid hpg;

	MyRotPosPathInterpolator(Alpha alpha,TransformGroup target,Transform3D axisOfRotPos,float[] knots,Quat4f[] quats,Point3f[] positions , byte cID , Hyperboloid hpg)
	{


			super( alpha, target, axisOfRotPos, knots, quats, positions );

			this.alpha 						= 	alpha;
		    this.target						= 	target;
		    this.axisOfRotPos			=	axisOfRotPos;
		    this.knots						=	knots;
		    this.quats						=	quats;
			this.positions					=	positions;
			this.cID							=  cID;
			this.hpg 							= hpg;

		}





	public void processStimulus( Enumeration criteria )
	{
		// Do something on a wakeup

		Transform3D t3D = new Transform3D();

 	    target.getTransform(t3D);

		Vector3d v3D = new Vector3d();
		t3D.get( v3D );

		double dbl[] = new double[3];
		v3D.get( dbl );

		double x = dbl[0];
		double y = dbl[1];
		double z = dbl[2];

 	    System.out.println("x = " + x + "  y = " + y + " z = " + z );


		if ( cID == 0 )
			hpg.posCoord[0].findXYZ( t3D );

		super.processStimulus( criteria );

   }
}