package Hyperview3D;

import java.util.Enumeration;
import javax.media.j3d.*;
import javax.media.j3d.Group.*;
import com.sun.j3d.utils.behaviors.vp.OrbitBehavior;
import com.sun.j3d.utils.universe.*;
import com.sun.j3d.utils.picking.behaviors.PickTranslateBehavior;
import com.sun.j3d.utils.picking.behaviors.PickingCallback;
import javax.vecmath.*;


/*

This class helps in propagating the transforms to other elements.
Whenever the cube is translated the callback method transformChanged is
called. In this method we copy the transform in other elements which required
a change in their position.

*/
public class MyPickTranslateBehavior extends PickTranslateBehavior implements PickingCallback
{


		TransformGroup tg;
		Hyperboloid hpg;
		PositionCoord posCoord;


		public MyPickTranslateBehavior(BranchGroup bg , Canvas3D c3D , Bounds bounds , TransformGroup tg , Hyperboloid hpg , PositionCoord posCoord)
		{
				//required
				super( bg , c3D , bounds);

				this.tg = tg;
				this.hpg = hpg;
				this.posCoord = posCoord;;
		}


	   //callback. Called by the JVM upon translation
	   public   void transformChanged(int type,  Transform3D t3d)
	   {

				Transform3D t3D = new Transform3D();

				//t3D contains the new transform
				tg.getTransform(t3D);

				//Set the  viewplatform's transform. This causes the camera to move and hence the view also changes
				hpg.setVPTransform( (byte)0 , t3D );


				//Update co-ordinates. These are the ones you see on the top right corner in each view
				posCoord.findXYZ( t3D );


				//Set the user's eye co-ords to new values.

				hpg.setObsX( posCoord.getX() );
				hpg.setObsY( posCoord.getY() );
				hpg.setObsZ( posCoord.getZ() );


				//Change the slider position only the z-value
			   ControlPanel.setSliderPos( (int)posCoord.getZ() );

	    }


 	    public   void transformChanged(int type,  TransformGroup tgx)   {   }


}