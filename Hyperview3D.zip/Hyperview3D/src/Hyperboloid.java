/**
*@author Kedar Bhumkar
*@version 1.0
*/



package Hyperview3D;



import static java.lang.Math.PI;

import javax.swing.*;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.*;
import java.awt.event.MouseListener;
import java.awt.GraphicsConfiguration;
import java.awt.Dimension;
import java.awt.Toolkit;

import com.sun.j3d.utils.applet.MainFrame;
import com.sun.j3d.utils.geometry.ColorCube;
import com.sun.j3d.utils.geometry.Sphere;
import com.sun.j3d.utils.geometry.Cone;
import com.sun.j3d.utils.geometry.Text2D;
import com.sun.j3d.utils.universe.*;
import com.sun.j3d.utils.behaviors.vp.OrbitBehavior;
import com.sun.j3d.utils.image.TextureLoader;
import com.sun.j3d.utils.behaviors.mouse.*;
import com.sun.j3d.utils.picking.behaviors.PickTranslateBehavior;
import com.sun.j3d.utils.picking.behaviors.PickRotateBehavior;
import com.sun.j3d.utils.picking.behaviors.PickZoomBehavior;
import com.sun.j3d.utils.picking.PickTool;

import javax.media.j3d.Font3D;
import javax.media.j3d.OrientedShape3D;
import javax.media.j3d.Screen3D;
import javax.media.j3d.*;
import javax.media.j3d.Group.*;
import javax.media.j3d.Text3D;
import javax.media.j3d.QuadArray;
import javax.media.j3d.ImageComponent2D;
import javax.media.j3d.Texture2D;
import javax.media.j3d.TexCoordGeneration;
import javax.media.j3d.TextureAttributes;
import javax.vecmath.*;

/*

   Constructs the 3D hyperboloid and the entire scenegraph associated with it.

*/

public class Hyperboloid
{

	// Create the root of the branch graph
	BranchGroup objRoot = new BranchGroup();

	//This class is responsible for actually showing the different models in the 2 screens.
	ModelViewer mV ;

	//default values - Refer to Properties.txt  for a complete listing
	private static float SCALE_FACTOR = 1.0f;
	private static int NO_OF_SLICES = 32/16;
	private static int NO_OF_ANG_DIVS = 128*2;
	private static double Z_HEIGHT = 2.45 ;
	private static float coneHT = 2.45f;


	private double dblThresholdValue;

	private TransformGroup tgParent = new TransformGroup();
	static   TransformGroup tgParentTemp = new TransformGroup();

	// Create Infinite Bounds
	private BoundingSphere 	infiniteBounds =	    new BoundingSphere(new Point3d(), Double.MAX_VALUE);

  	//2 views side and Model
  	static final byte noOfViews = 2;

	//Image to be texture mapped
	static String strImage;

	//Enables to have 2 views
	private MultiUniverse u;

	//2 views hence 2 canvases
	Canvas3D arrCanvas3D[] = new Canvas3D[noOfViews];

	//2 views hence 2 'view' objects
	private View vw[] = new View[noOfViews];

	//2 views hence 2 orbitbehaviors
	private static OrbitBehavior orb[] = new OrbitBehavior[noOfViews];


    //A viewplatform AVATAR object. This makes it possible to manipulate the camera ( the cube you see in side view) with mouse.
	private static VPAvatar vpAVT ;

	//This the transformGroup for the VPAvatar
	private static TransformGroup vpBG;

   //These classes allow manipulation of the VPAvatar ( the cube). In Java3D it is called as Picking
   MyPickTranslateBehavior pickTrans ;
   MyPickRotateBehavior pickRot;
   MyPickZoomBehavior pickZm;


   PositionCoord posCoord[] = new PositionCoord[noOfViews];

   Color clr[] = new Color[] {  Color.yellow ,Color.yellow};

	private static Animation anim1 , anim2 ;

	private Appearance appQ = new Appearance();
    private  Texture2D tx2d ;
	private PolygonAttributes pAttrQ;

	//This is for the 3D bounding Cone
	private TransformGroup tgCone = new TransformGroup();
    private Cone cc = new Cone ( 2.45f ,coneHT );

	//BranchGroup object for the bounding cone
	BranchGroup bgCone = new BranchGroup();

	ModelSelectorPanel msp1;
	ModelSelectorPanel msp2;


	//Constructor
   	Hyperboloid()
   	{

   		posCoord[0] = new PositionCoord((byte)0 , this);
   		posCoord[1] = new PositionCoord((byte)1 , this);

	}


/*

   Sets the appropriate button when the 3d Hyperboloid passes through
   co-ordinates corresponding to th models during animation

 */

void modifyModelRadioDisplay( byte frameID , byte modelNo)
{


	  JPanel jpModel = msp1;

	   if( frameID == 1)
	      jpModel = msp2;


	  ((ModelSelectorPanel)jpModel).klienButton.setSelected( false);
	  ((ModelSelectorPanel)jpModel).poincareButton.setSelected( false);
	  ((ModelSelectorPanel)jpModel).gansButton.setSelected( false);



	  switch( modelNo )
	  {

		 case -100:
						((ModelSelectorPanel)jpModel).noneButton.setSelected( true);
		 				break;

		  case 0 :
		  				((ModelSelectorPanel)jpModel).klienButton.setSelected( true);
		                 break;

		  case 1:
		  				((ModelSelectorPanel)jpModel).poincareButton.setSelected( true);
		  				 break;

		  case 2:
		  				((ModelSelectorPanel)jpModel).gansButton.setSelected( true);
		  				 break;

	  }



}


/*
  Enables/Disables the bounding cone surrounding the 3D hyperboloid.
*/

void enableBoundingCone( boolean blnOn )
{

	   if( blnOn )
	   		tgParentTemp.addChild( bgCone );
	   else
	      {
			  tgParentTemp.removeChild( bgCone );
			  bgCone.detach();
		 }

}

/*
  Save the location from which image would be uploaded.
*/

void setTextureImagePath( String  strImage )
{

	this.strImage = strImage;

}

//set Texture back
void setTexture(boolean blnON)
{
		if(blnON)
			appQ.setTexture(tx2d);
		else
			appQ.setTexture(null);

}

/*
 Enables/Disables wireframe on the 3D hyperboloid.
*/
void setWireFrameMode( boolean blnON)
{

		 if(blnON)
		 {
			 setTexture( false );
			 pAttrQ.setPolygonMode(PolygonAttributes.POLYGON_LINE);
		}
		else
		 {

			 pAttrQ.setPolygonMode(PolygonAttributes.POLYGON_FILL);
			 setTexture( true );



		 }

}

// Animation start/stop
    static void setAnim1Enable( boolean animEn )
	{

			anim1.setEnable( animEn);

	}

// Animation start/stop
    static void setAnim2Enable( boolean animEn )
	{

			anim2.setEnable( animEn);

	}


// public access methods
	void setObsX( double x )
	{

		 mV.OBSERVER_POSITION_X = x;

	}


	void setObsY( double y )
	{

		 mV.OBSERVER_POSITION_Y = y;

	}

	void setObsZ( double z )
	{

		 mV.OBSERVER_POSITION_Z = z;

	}

// set the Avatar object's transform
	static void setvpAVTTransform( Transform3D t3D )
	{

		vpAVT.setTransform( t3D );


	}

//set Pickable property of the Avatar Object
	static void setvpBgPickable( boolean blnPick )
	{

			vpBG.setPickable( blnPick );

	}

	void pickingEnable( boolean blnEnable)
	{


	   pickTrans.setEnable( blnEnable ) ;
	   pickRot.setEnable( blnEnable );
	   pickZm.setEnable( blnEnable );

	}


	//Set theViewPlastform transform for the appropriate view indicated by cID
	void setVPTransform( byte cID , Transform3D t3D )
	{


		u.getViewingPlatform( cID ).getViewPlatformTransform().setTransform( t3D );


	}


//OrbitBehavior Zoom on/off
    static void setOrbZoomEnable( boolean zmEn )
	{

			orb[1].setZoomEnable( zmEn);

	}

//OrbitBehavior Translate on/off
    static void setOrbTranslateEnable( boolean trEn )
	{

			orb[1].setTranslateEnable( trEn);

	}

//OrbitBehavior Rotate on/off
    static void setOrbRotateEnable( boolean rtEn )
	{

			orb[1].setRotateEnable( rtEn);

	}


	/*
	   Create the scenegraph tree with all the elements
	   and return the root BranchGroup

	 */

    public BranchGroup createSceneGraph()
    {

			mV = new ModelViewer(u  , this);

			//Ensble picking so manipulation via mouse is possible
			objRoot.setPickable( true );


			// Create the co-ordinate axis
			createAxis( objRoot);

			//create the 3D Wireframe Model
			createWireHyperboloid(objRoot);

			//Create the 3D Bounding Cone
			createBoundingCone( objRoot);

			/*
			Display points ( spheres) at positions from where Klein
			and Poincare model would be viewed.
			*/
			createModelPoints(objRoot);

			tgParentTemp.setPickable( false );
			objRoot.addChild( tgParentTemp );


			// Have Java 3D perform optimizations on this scene graph.
			objRoot.compile();

			return objRoot;
    }



	public static void setNO_OF_SLICES( int noSlices)
	{

		NO_OF_SLICES = noSlices;

	}


	public static void setNO_OF_ANG_DIVS( int noAngDivs)
	{

		NO_OF_ANG_DIVS = noAngDivs;

	}

	public static void setZ_HEIGHT( double zH)
	{

		Z_HEIGHT = zH;

	}


    public static void setSCALE_FACTOR( float scaleFac )
	{

		SCALE_FACTOR	 = scaleFac;


	}



//This shows the points from where different models would be visible if the user views them from
 //this position

private void createModelPoints(BranchGroup objRoot)
{


		 Vector3d  v3dTrans[] =   new Vector3d[] {  new Vector3d( 0.0 , 0.0 , 0.0) , new Vector3d( 0.0 , 0.0 , -1.0) };


		for( byte i=0 ; i<2 ;i++)
		{

			addSphere(v3dTrans[i]);

		}
}

//Show the points

private void addSphere( Vector3d v3dTrans)
{



		TransformGroup tg = new TransformGroup();


		Transform3D t3D    = new Transform3D();
		t3D.setTranslation(v3dTrans  );
		Sphere sph = new Sphere(0.1f/2, giveSphereApp( 1.0f, 1.0f, 1.0f ));
		tg.setTransform( t3D );
		tg.addChild( sph );
		objRoot.addChild( tg );

}

//set appearance of each point ( or sphere )
private Appearance giveSphereApp(float colX , float colY , float colZ )
{


		ColoringAttributes colrAttrib = new ColoringAttributes( colX, colY, colZ, ColoringAttributes.NICEST);

		Appearance app = new Appearance();
		app.setColoringAttributes( colrAttrib );
		app.setTransparencyAttributes( new TransparencyAttributes(TransparencyAttributes.NICEST, 0.6f) ) ;
		return app;



}


/*
  For future use if lighting is incorporated
*/

/*
public void defineLightSource( BranchGroup objRoot)
	{

		Point3f v3fLightDirection = new Point3f(1.0f , 1.0f , 0.5f );
		Color3f c3fRed = new Color3f(0.2f, 0.2f, 0.2f);

		PointLight dirLight = new PointLight ( c3fRed , v3fLightDirection, new Point3f( 0.0f , 1.0f , 0.0f)  ) ;
		dirLight.setInfluencingBounds( new BoundingSphere(new Point3d(), Double.MAX_VALUE) );

		dirLight.setCapability( Light.ALLOW_STATE_WRITE);
	}

*/

	/*

		This creates the 3D wireframe hyperboloid

	*/
	private void createWireHyperboloid( BranchGroup objRoot)
	{
			 int iSize = NO_OF_SLICES * NO_OF_ANG_DIVS * 4;

			 TransformGroup tg = new TransformGroup();
			 Transform3D t3dScale = new Transform3D(  );
			 t3dScale.setScale( SCALE_FACTOR) ;
			 tg.setTransform( t3dScale );

			//This will store the 3D hyperboloid co-ordinates.
			Point3d p3d[] = new Point3d[iSize];
			HyperboloidPointGenerator hpg = new HyperboloidPointGenerator();
			hpg.setParameters(  (float)Z_HEIGHT , NO_OF_SLICES , NO_OF_ANG_DIVS  );
			hpg.generatePoints( p3d );
			dblThresholdValue =hpg.getThresholdValue();


			// define the Geometry of the shape
			Geometry qA  = defineGeometry(p3d);

			// define the Appearance of the shape
			defineAppearance();
			Shape3D s3D = new  Shape3D(qA, appQ) ;

		    tg.addChild( s3D );
			tgParentTemp.addChild( tg );

	}

   /*
      Create the bounding cone around the 3D hyperboloid
  */
   private void createBoundingCone( BranchGroup objRoot)
   {

			tgParentTemp.setCapability( TransformGroup.ALLOW_CHILDREN_READ);
			tgParentTemp.setCapability( TransformGroup.ALLOW_CHILDREN_WRITE);
			tgParentTemp.setCapability( TransformGroup.ALLOW_CHILDREN_EXTEND);

			bgCone.setCapability( BranchGroup.ALLOW_DETACH);
			ColoringAttributes colrAttrib = new ColoringAttributes(new Color3f( new Color(240,128,128)),ColoringAttributes.NICEST);

			Appearance app = new Appearance();
			app.setColoringAttributes( colrAttrib );
			app.setTransparencyAttributes( new TransparencyAttributes(TransparencyAttributes.NICEST, 0.6f) ) ;
			cc.setAppearance( app );
		 	Transform3D t3d = new Transform3D(  );

			 t3d.setTranslation( new Vector3d( 0.0 , 0.0 , coneHT/2) );
			 t3d.setScale( SCALE_FACTOR) ;
			 t3d.setRotation( new AxisAngle4f( 1 , 0, 0 , -(float)(Math.PI/2)));
			 tgCone.setTransform( t3d );
			 tgCone.addChild( cc );

			 bgCone.addChild( tgCone);

   }


	private void defineAppearance()
	{

		    // define the Geometry of the shape
			pAttrQ = new PolygonAttributes(PolygonAttributes.POLYGON_FILL, PolygonAttributes.CULL_NONE,1, true, -1);
			pAttrQ.setCapability(PolygonAttributes.ALLOW_MODE_WRITE );
			appQ.setPolygonAttributes (pAttrQ);

			// Patch Material
			createMaterial(  );

			// Map Texture
			createTexture(  ) ;

			//Generate texture co-ordinates
			generateTextureCoords() ;

	}

   /*
     Might be useful in the future.
   */

	private void createMaterial( )
	{

 		 Color3f black = new Color3f(1.0f, 0.0f, 0.0f);
		 Color3f white = new Color3f(1.0f, 0.0f, 1.0f);
		appQ.setMaterial(new Material(white, black, white, black, 1.0f));

	}



	/*
	   Java3D automatically generates texture co-ords. dblThresholdValue is the w-co-ordinate
	   Pls see Java Doc for more info
	   http://download.java.net/media/java3d/javadoc/1.3.2/javax/media/j3d/TexCoordGeneration.html
	*/

	private  void generateTextureCoords( )
	{

			TexCoordGeneration texGen = new TexCoordGeneration(TexCoordGeneration.OBJECT_LINEAR,TexCoordGeneration.TEXTURE_COORDINATE_2 );
			texGen.setPlaneS( new Vector4f((float)(1.0/(dblThresholdValue*2)) , 0.0f ,0.0f ,0.5f) );
			texGen.setPlaneT( new Vector4f(0.0f , (float)(1.0/(dblThresholdValue*2)) ,0.0f ,0.5f) );
			appQ.setTexCoordGeneration(texGen );

	}


	//Map the image as a texture on the 3D hyperboloid
	private void createTexture( )
	{
		    //define the texture
			appQ.setCapability( Appearance.ALLOW_TEXTURE_WRITE);
			loadTexture();
			TextureAttributes txAttr = new TextureAttributes();
			txAttr.setTextureMode(TextureAttributes.MODULATE);
			appQ.setTextureAttributes(txAttr);

	        setTexture( true );

	}

 /*
     Load the image as a texture. Java3D  requires images to be inpixel sizes of 64 by 64, 256 by 256 etc

   */

	void loadTexture( )
	{

				NewTextureLoader txLd = new NewTextureLoader( strImage);
				ImageComponent2D imgC2d = txLd.getScaledImage(256,256);

				tx2d = new Texture2D( Texture2D.BASE_LEVEL, Texture.RGB, imgC2d.getWidth(), imgC2d.getHeight());
				tx2d.setMagFilter(Texture2D.FILTER4);
				tx2d.setImage( 0, imgC2d );
				tx2d.setEnable( true );

	}

	private Geometry defineGeometry( Point3d p3d[]  )
	{
				int iSize = p3d.length;
				TexCoord2f[] textCoord = 	new TexCoord2f[iSize];

				QuadArray   qA = new QuadArray( iSize , QuadArray.COORDINATES |  QuadArray.TEXTURE_COORDINATE_2);
				qA.setCoordinates( 0 , p3d ) ;
				Color3f clrs[] = new Color3f[iSize];

				float fx = 0.0f;
				float fy = 0.0f;

				for ( int i = 0 ; i < iSize ; i++)
					{
						//clrs[i] = new Color3f( 0.4f , 0.4f , 0.7f );
						fx+=0.001f;
						if( fx == 1.0f)
						  {
								fy+=0.001f;
								fx =0.0f;
						  }
						   textCoord[i] = new  TexCoord2f( fx ,fy);
				   }

				//qA.setColors( 0 , clrs);
				qA.setTextureCoordinates( 0 ,0,textCoord );

				return qA;




	}

	/*
		Create the labels for the axes (+ve as well as -ve)
	*/

	private void createLabels( BranchGroup objRoot)
	{


				Font3D f3d = new Font3D( new Font(null , Font.BOLD, 100 ) ,null);
				Appearance app = new Appearance();
				app.setColoringAttributes( new ColoringAttributes( new Color3f( 0.5f , 1.0f , 0.5f), ColoringAttributes.SHADE_FLAT ));
				Point3f p3f = new Point3f( 0.0f , 0.0f , 0.0f );


				String strLabels[] = new String[] { "0" , "X", "Y" , "Z" , "-X", "-Y" , "-Z"};
				float scale = 0.0025f*1.2f;

				Object v3f[] = new Object [] {   new Vector3f( 0.0f , 0.0f , 0.0f) ,  new Vector3f( 1.0f, 0.0f , 0.0f) ,  new Vector3f( 0.0f , 1.0f,  0.0f) ,  new Vector3f( 0.0f , 0.0f , 1.0f) ,new Vector3f( -1.0f, 0.0f , 0.0f) ,  new Vector3f( 0.0f , -1.0f , 0.0f ) ,  new Vector3f( 0.0f , 0.0f , -1.0f)   } ;

				for ( byte i = 0 ; i < 7 ; i++)
				  {

						Text3D t3dOrigin = new Text3D( f3d, strLabels[i] );
						OrientedShape3D o3d = new OrientedShape3D( t3dOrigin ,app, OrientedShape3D.ROTATE_ABOUT_POINT,p3f);
						tgParentTemp.addChild( addLabels( scale , v3f[i] , o3d  )  );
				   }
		 }

	/*
	   Add the labels to the transform group
	*/
	private TransformGroup  addLabels( float scale , Object v3f , OrientedShape3D o3d )
		{


				TransformGroup tg = new TransformGroup();
				Transform3D t3dScale = new Transform3D(  );
				t3dScale.setScale( scale ) ;
				t3dScale.setTranslation(  ( Vector3f)v3f  );

				tg.setTransform( t3dScale );
				tg.addChild( o3d );

				return tg;

		}

		//Create the 3 Co-ordinate axes
		private void  createAxis( BranchGroup objRoot)
		{
			  Axis axisMain = new Axis();
			  TransformGroup tg = axisMain.createAxis(  SCALE_FACTOR , 30.0f , 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f  ) ;
			  tgParentTemp.addChild( tg );
		}

		// Called by Invoker.
		public void init( ModelSelectorPanel msp1, ModelSelectorPanel msp2 )
		{

			this.msp1 = msp1;
			this.msp2 = msp2;

			//Start the 3D rendering process
			generateSceneGraph();

		}

		//Develops the Java 3D scenegraph. For more info (http://download.java.net/media/java3d/javadoc/1.4.0/javax/media/j3d/doc-files/SceneGraphOverview.html)
		private void generateSceneGraph()
		{



		   tgParent.setCapability( TransformGroup.ALLOW_TRANSFORM_WRITE);
		   tgParent.setCapability( TransformGroup.ALLOW_TRANSFORM_READ);
		   tgParent.setCapability(TransformGroup.ENABLE_PICK_REPORTING);

			tgParentTemp.setCapability( TransformGroup.ALLOW_TRANSFORM_WRITE);
			tgParentTemp.setCapability( TransformGroup.ALLOW_TRANSFORM_READ);
			tgParentTemp.setCapability(TransformGroup.ENABLE_PICK_REPORTING);


			//Create Canvas 3D
			GraphicsConfiguration config =     SimpleUniverse.getPreferredConfiguration();

			//We use multiuniverse bcos we have 2 views
			u = new MultiUniverse( noOfViews );

			//2 view branches are required one for each view
			for ( byte cID = 0 ; cID<noOfViews ;cID++)
						 createViewBranch(cID,config);

			//create an AVATAR ( the cube) so that the user can manipulate the scene by moving it around
			vpAVT = new  VPAvatar();
			vpBG = vpAVT.createBranchGroup();
			vpBG.setCapability(TransformGroup.ALLOW_PICKABLE_READ);
			vpBG.setCapability(TransformGroup.ALLOW_PICKABLE_WRITE );

			//Picking - Enables translation of the viewplatform ( and the cube  ) by mouse
			pickTrans = new MyPickTranslateBehavior(objRoot, arrCanvas3D[1],  infiniteBounds, vpBG , this , posCoord[0]);
			pickTrans.setSchedulingBounds( infiniteBounds);
			pickTrans.setupCallback( pickTrans );
			objRoot.addChild(pickTrans);

			//Picking - Enables rotation of the viewplatform ( and the cube  ) by mouse
			pickRot = new MyPickRotateBehavior(objRoot, arrCanvas3D[1],  infiniteBounds, vpBG , this,posCoord[0] );
			pickRot.setSchedulingBounds( infiniteBounds);
			pickRot.setupCallback( pickRot );
			objRoot.addChild(pickRot);


			//Picking - Enables zooming of the viewplatform ( and the cube  ) by mouse
			pickZm = new MyPickZoomBehavior(objRoot, arrCanvas3D[1],  infiniteBounds, vpBG , this, posCoord[0]);
			pickZm.setSchedulingBounds( infiniteBounds);
			pickZm.setupCallback( pickZm );
			objRoot.addChild(pickZm);


			objRoot.addChild( vpBG );


		  //Enables/Disables  animation for hyperboloid in ModelView
		  anim1= new Animation(u.getViewingPlatform(0).getViewPlatformTransform(), objRoot , (byte)0 , this);
		  anim1.startAnimation();
		  Hyperboloid.setAnim1Enable( false);

		 //Enables/Disables  animation for the Avatar in ModelView
		  anim2 = new Animation(vpBG, objRoot , (byte)1 , this);
		  anim2.startAnimation();
		  Hyperboloid.setAnim2Enable( false);

		 // Create a simple scene and attach it to the virtual universe
		 BranchGroup scene = createSceneGraph();

		//Creates default position for viewer in both the views
		for ( byte cID = 0 ; cID<noOfViews ;cID++)
			setInitialUserPosition( (byte)cID );

			//Create background
			BranchGroup bgBackground = createBackground(  infiniteBounds );

			// Add Background
			u.addBranchGraph( bgBackground );


			//Add Scene
			 u.addBranchGraph(scene);
		}


	/*

		   Creates the 3D view branch for each view Model and Side view
			java.sun.com/products/java-media/3D/forDevelopers/J3D_1_2_API/j3dguide/Concepts.html

	*/
	private void createViewBranch(byte cID, GraphicsConfiguration config)
	{


			//Create Canvas 3D
			arrCanvas3D[cID] = new MyCanvas3D(config , posCoord[ cID ] , clr[cID] );

			//Create the actual view object
			vw[cID] = u.createView( arrCanvas3D[cID] );

			// Add Orbit behavior for the view branch. This allows to move arounf the 3D hyperboloid using a mouse.
			if( cID == 1)
			{
				orb[cID] = new  MyOrbitBehavior ( arrCanvas3D[cID]  , u.getViewingPlatform(cID).getViewPlatformTransform() , cID , posCoord[ cID ] ) ;
				orb[cID].setSchedulingBounds(infiniteBounds);
				u.getViewingPlatform(cID).setViewPlatformBehavior(orb[cID]);
			 }

	}

			// Set the default model (Klein) in both the views
			private void setInitialUserPosition(  byte cID )
			{
				if( cID == 0 )
				 {

						mV.klienModel(vw[0],tgParent);
				 }
				 else
				 {

						mV.SECOND_OBSERVER_POSITION_X =-4.0;
						mV.isometricKlienModel( vw[1],tgParent )	;
				 }
			}

		   /*
			  Sets the viewer's position to view the specific model in
			  both the views.

		   */

			void showModel( String strModel , double dblZvalue , byte frameID)
			{

					if( strModel.equals("PoincareKlien"))
					  {

						  if( frameID == 0 )
							{
							   mV.OBSERVER_POSITION_Z = dblZvalue;
							   mV.klienModel(vw[0],tgParent);
							}
						   else
						   {
								mV.SECOND_OBSERVER_POSITION_X = 0.0;
								mV.SECOND_OBSERVER_POSITION_Y = 0.0;
								mV.SECOND_OBSERVER_POSITION_Z = dblZvalue;
								mV.isometricKlienModel( vw[1],tgParent );
						   }

					  }
					else if( strModel.equals("Gans"))
					 {

						  if( frameID == 0 )
						   {
								mV.OBSERVER_POSITION_Z = dblZvalue;
								mV.gansModel(vw[0],tgParent);
							}
						  else
							{

								mV.isometricGansModel( vw[1],tgParent );

							}


					 }
			}


		  /*

		   Set the background of the scene.

		  */


		   private BranchGroup createBackground( BoundingSphere infiniteBounds  )
		   {

				BranchGroup bgBackground  = new BranchGroup();
				Color3f clrWhite = new Color3f( 0.0f , 0.0f , 0.0f );
				Background bdBackground = new Background( clrWhite);
				bdBackground.setApplicationBounds( infiniteBounds);
				bgBackground.addChild( bdBackground);

				return( bgBackground );


		   }

			public void destroy()
			{
				u.cleanup();
			}


		Canvas3D getCanvases(byte cID)
		{

			  return ( arrCanvas3D[cID] );

		}
}
