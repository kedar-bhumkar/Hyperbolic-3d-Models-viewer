package Hyperview3D;

import javax.media.j3d.Transform3D;
import javax.vecmath.Vector3d;


public class  PositionCoord
{

   byte 	frameID;
   Hyperboloid hpg;
   private double x , y , z;
   private String strProjType;


  PositionCoord(  byte frameID, Hyperboloid hpg  )
  {

	   this.frameID = frameID;
	   this.hpg = hpg;

  }

   void findXYZ(  Transform3D t3D )
   {


		Vector3d v3D = new Vector3d();
		t3D.get( v3D );

		double dbl[] = new double[3];

		v3D.get( dbl );
		x = dbl[0];
		y = dbl[1];
		z = dbl[2];

		findModel();


   }

void findModel()
{


	//System.out.println( " Inside findModel");

	if( strProjType.equals("Parallel."))
	    hpg.modifyModelRadioDisplay(frameID ,(byte)2);
	else
	   {

		   if( x == 0.0 && y == 0.0 && z == 0.0)
		     {
				 ///System.out.println( "Inside findModel()  Klein");
				 hpg.modifyModelRadioDisplay(frameID ,(byte)0);

			}
		   else if( x == 0.0 && y == 0.0 && z == -1.0)
		     {
				 //System.out.println( "Inside findModel() Poincare");
				 hpg.modifyModelRadioDisplay(frameID ,(byte)1);
		 	 }
		    else
			 {
				 //System.out.println( "Inside findModel()  Non-Model");
				 hpg.modifyModelRadioDisplay(frameID ,(byte)-100);
			}

	   }



}


  void setProjType( String strProjType)
  {

	  this.strProjType = strProjType;


  }

 String getProjType()
 {

	 return strProjType;

 }





   double getX()
   {


	    return x;

   }


   double getY()
   {


	    return y;

   }

   double getZ()
   {


	    return z;

   }


   void setX(double x)
   {


	    this.x = x;

   }


   void setY(double y)
   {


	    this.y = y;

   }

   void setZ(double z)
   {


	    this.z = z;
		findModel();


   }


}