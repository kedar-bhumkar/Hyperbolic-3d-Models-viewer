package Hyperview3D;


import javax.swing.*;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Color;
import java.awt.LayoutManager;
import java.awt.event.*;
import java.io.File;
import java.beans.PropertyVetoException;



//Parent class calls others

public class Invoker implements ActionListener
{
			private JFileChooser fc = new JFileChooser();
			private JDesktopPane desktop; // This holds the 3 internal frames viz Side View , Model View and Control Panel at the bottom

			static Hyperboloid  hyp;  // The 3D hyperboloid

			private static final int parFrSizeX  	 = 1005;
			private static final int parFrSizeY 	 = 750;
			private static final int modVwLocX	 = 500;
			private static final int vwLocY 			 = 0;
			private static final int vwSize            = 500;

			ModelSelectorPanel msp1;  //This holds the 3 radio buttons( model selectors) for the Model View
			ModelSelectorPanel msp2;  //This holds the 3 radio buttons( model selectors) for the Side View


			//Program entry point
			public static void main(String[] args)
			{
				Invoker inv = new Invoker();
				inv.getcommandLineProps( args);
				inv.createGui();
			}

			//Create the GUI interface
			private void createGui()
			{


				Toolkit tk = Toolkit.getDefaultToolkit();
				Dimension d = tk.getScreenSize();

				//This is needed bcos you can't add internal frames directly to desktop
				final JFrame jfParent = new JFrame();
				jfParent.setTitle( "HyperView 3D" );


				desktop = new JDesktopPane( );


				//Add Desktop ( this enables adding of internal frames)
				jfParent.setContentPane(desktop);
				jfParent.setSize(parFrSizeX, parFrSizeY);
				jfParent.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				desktop.setBackground(Color.WHITE);

				//Menubar
				jfParent.setJMenuBar(createMenuBar());

				//Model View Frame
				final JInternalFrame jf1 = new JInternalFrame( "K", false , false , true);
				setFrameProperties( jf1, (int)d.getWidth()-modVwLocX-1, vwLocY,"Model View" , vwSize, vwSize , d, new BorderLayout());

				//Side View Frame
				JInternalFrame jf2 = new JInternalFrame("K", false , false , true );
				setFrameProperties( jf2, (int)d.getWidth(),vwLocY,"Side View" , vwSize , vwSize , d , new BorderLayout());

				//Control Panel Frame
				JInternalFrame jf3 = new JInternalFrame( );
				setFrameProperties( jf3, (int)d.getWidth(),vwSize + vwLocY,"Control Panel" , parFrSizeX , parFrSizeY -(vwSize + vwLocY) , d ,new  FlowLayout() );

				//Initialize the model selector panels
				msp1 = new ModelSelectorPanel( hyp , (byte)0);
				msp2 = new ModelSelectorPanel( hyp , (byte)1);

				//This will enable the 3d Rendering of the hyperb oloid in both the screens
				hyp.init(msp1 , msp2);

				//Actual 3D rendering is done on a Canvas hence this needs to be added to the internal JFrame

				jf1.add(hyp.getCanvases((byte)0),BorderLayout.CENTER);
				jf2.add(hyp.getCanvases((byte)1),BorderLayout.CENTER);


				jf1.add( msp1 , BorderLayout.SOUTH);
				jf2.add( msp2  , BorderLayout.SOUTH);

				ControlPanel cPan = new ControlPanel(hyp);
				jf3.add(cPan);


				jf1.setVisible(true);
				jf2.setVisible(true);
				jf3.setVisible(true);

				jfParent.setVisible(true);

				desktop.add(jf1);
				desktop.add(jf2);
				desktop.add(jf3);


				jfParent.addWindowStateListener(  new MyWindowStateListener(parFrSizeX, parFrSizeY, 750,775 , jfParent, jf1,vwSize,desktop) );

	}


		//Create the top level menu
		private JMenuBar createMenuBar()
		{

				JMenu fileMenu = new JMenu("File");
				fileMenu.getPopupMenu().setLightWeightPopupEnabled(false);

				JMenuItem loadChoice = new JMenuItem("Load Image");
				loadChoice.addActionListener(this);
				fileMenu.add(loadChoice);

				JMenuItem exitChoice = new JMenuItem("Exit");
				exitChoice.addActionListener(this);
				fileMenu.add(exitChoice);


				JMenu helpMenu = new JMenu("Help");

				JMenuBar bar = new JMenuBar( );

				bar.add(fileMenu);
				bar.add(helpMenu);


  			    return bar;

		}


			//GUi callback to take actions on user events
			public void actionPerformed(ActionEvent e)
			{
				String actionCommand = e.getActionCommand();

				if(actionCommand.equals("Load Image"))
				{

						int returnVal = fc.showOpenDialog(desktop);

						if (returnVal == JFileChooser.APPROVE_OPTION)
						{
							File file = fc.getSelectedFile();
							System.out.println("File Path = " + file.getAbsolutePath());
							fc.setCurrentDirectory( fc.getCurrentDirectory() );

							hyp.setTextureImagePath(file.getAbsolutePath());
							hyp.loadTexture();
							hyp.setTexture( true );
					   }


			      }
				  else if(actionCommand.equals("Exit"))
						  System.exit(0);
			   }


			//Check if an image file is specified via a command line. If yes, record it's path and set it in the 3D hyperboloid class (hyp)
			private static void getcommandLineProps(String args[])
			{

			  String strImagePath = "EscherPattern.jpg";
			  hyp = new Hyperboloid();

			  if ( args.length!=0)
				{

					strImagePath = args[0];

				}

				 hyp.setTextureImagePath(strImagePath);

			}

			//Set the internal frames display properties
			private static void setFrameProperties( JInternalFrame jf, int xPosOffset , int yPos , String strTitle , int xSize , int ySize , Dimension d , LayoutManager layOt)
			{


				jf.setLayout(layOt);
				jf.setTitle(strTitle);
				jf.setSize( xSize, ySize );
				jf.setLocation( (int)(d.getWidth() -xPosOffset),yPos);

				jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

				System.out.println("X-pos = " + (int)(d.getWidth() - xPosOffset ));
				System.out.println("Y-pos = " + (int)(d.getHeight() - yPos));
			}



}