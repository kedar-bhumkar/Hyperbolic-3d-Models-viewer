package Hyperview3D;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;

class ControlPanel extends JPanel implements ItemListener, ChangeListener , ActionListener
{

	Hyperboloid hpg;
	JCheckBox jCb1, jCb2, jCb3, jCb4, jCb5 ;
	JTextField jTf1 , jTf2 , jTf3;
	static final Color clrIncorr =  new Color(255, 140, 0);
	static final Color clrCorr   =  new Color(255, 255, 255);
	static JSlider slider = new JSlider(JSlider.HORIZONTAL,-12, 0, 0);
	static boolean blnDoNotResetXY = false;

	//access method

	static void setSliderPos( int pos )
	{
		  blnDoNotResetXY = false;
		  slider.setValue( pos );
	}


   ControlPanel( Hyperboloid hpg)
   {

   		this.hpg= hpg;

   		setLayout( new GridLayout( 3, 1) );

   		createGui();


   }

   void createGui()
   {

		add( createPanel1() );
		add( createPanel2() );
		add( createPanel3() );



   }


JPanel createPanel1()
{

	 JPanel jp = new JPanel();

	 jCb1 = new JCheckBox("OrbitBehavior");
	 jCb1.setActionCommand("OrbitBehavior");
	 jCb1.setSelected( true );

	 jCb2 = new JCheckBox("Animation");
	 jCb2.setActionCommand("Animation");



	 jCb3 = new JCheckBox("Camera Motion");
	 jCb3.setActionCommand("Camera");
	 jCb3.setSelected( true );

	 jCb4 = new JCheckBox("Wireframe");
	 jCb4.setActionCommand("Wireframe");
	 jCb4.setSelected( false );

	 jCb5 = new JCheckBox("Bounding Cone");
	 jCb5.setActionCommand("Bounding Cone");
	 jCb5.setSelected( false );

	 jCb1.addItemListener( this  );
	 jCb2.addItemListener( this  );
	 jCb3.addItemListener( this  );
	 jCb4.addItemListener( this  );
	 jCb5.addItemListener( this  );

	 jp.add( jCb1 );
	 jp.add( jCb3 );
	 jp.add( jCb2 );
	 jp.add( jCb4 );
	 jp.add( jCb5 );

	 return jp;
}

JPanel createPanel2()
{

	 JPanel jp = new JPanel();

	  JLabel jl1 = new JLabel( "X = ");
	  jTf1 = new JTextField("0.00",4);

	  JLabel jl2 = new JLabel( "Y = ");
	  jTf2 = new JTextField("0.00",4);

	 JLabel jl3 = new JLabel( "Z = ");
	 jTf3 = new JTextField("0.00",4);



	 jp.add( jl1 );
	 jp.add( jTf1 );
	 jp.add( jl2 );
	 jp.add( jTf2 );
	 jp.add( jl3 );
	 jp.add( jTf3 );

	 JButton jb = new JButton( "Go");
	 jb.setActionCommand("Fly");
	 jb.addActionListener( this );
	 jp.add( jb );

	return jp;
}



JPanel createPanel3()
{

	 JPanel jp = new JPanel();


    //slider.setBorder(BorderFactory.createTitledBorder("Z- Adjustor"));
    slider.setMajorTickSpacing(4);
    slider.setMinorTickSpacing(1);
    slider.setPaintTicks(true);
    slider.setPaintLabels(true);
	slider.addChangeListener( this );

    jp.add(slider);
    return jp;
}


   public void itemStateChanged(ItemEvent e)
  {

		Object source = e.getItemSelectable();
		if( source == jCb1)
		 {
				if (e.getStateChange() == ItemEvent.DESELECTED)
				  {
						Hyperboloid.setOrbZoomEnable( false);
						Hyperboloid.setOrbTranslateEnable( false);
						Hyperboloid.setOrbRotateEnable( false);
				 }
				 else
				 {
						Hyperboloid.setOrbZoomEnable( true);
						Hyperboloid.setOrbTranslateEnable( true);
						Hyperboloid.setOrbRotateEnable( true);

				 }
		 }
		else if( source == jCb2 )
		{
				if(e.getStateChange() == ItemEvent.DESELECTED)
				{
				  	  Hyperboloid.setAnim1Enable( false);
				  	  Hyperboloid.setAnim2Enable( false);
			     }
				else
				{
					  Hyperboloid.setAnim1Enable( true);
					  Hyperboloid.setAnim2Enable( true);
				}

         }
		else if( source == jCb3 )
		{
				if(e.getStateChange() == ItemEvent.DESELECTED)
				     hpg.pickingEnable(  false);
				else
					 hpg.pickingEnable( true);


         }
		else if( source == jCb4 )
		{
				if(e.getStateChange() == ItemEvent.DESELECTED)
				   hpg.setWireFrameMode( false );
				else
				   hpg.setWireFrameMode( true );
         }
		else if( source == jCb5 )
		{
				if(e.getStateChange() == ItemEvent.DESELECTED)
				   hpg.enableBoundingCone( false );
				else
				   hpg.enableBoundingCone( true );
         }

    }

	public void stateChanged(ChangeEvent e)
	{
			System.out.println( " In Slider StateChanged  ");
	    	JSlider slider = (JSlider)e.getSource();
            int zValue = (int)slider.getValue();

			if(hpg.mV.getCurrentModel() == false)
			     hpg.showModel("PoincareKlien",zValue , (byte)0);
			else
			    hpg.showModel("Gans",zValue , (byte)0);
	 }


public void actionPerformed(ActionEvent e)
{

		String strModel = e.getActionCommand();

		System.out.println( "Inside Fly callback");



		if( strModel.equals("Fly"))
		 {
				try
				{

						String strX = (jTf1.getText().trim());
						String strY = (jTf2.getText().trim());
						String strZ = (jTf3.getText().trim());

						System.out.println( " strX = " + strX);
						System.out.println( " strY = " + strY);
						System.out.println( " strZ = " + strZ);

						if(strX.length()!=0 && strY.length()!=0 && strZ.length()!=0)
						{
								hpg.setObsX(  new Double( strX ) );
								hpg.setObsY(  new Double( strY ) );
								//hpg.showModel( "PoincareKlien" ,  new Double( strZ ) , (byte)0 );

								if(hpg.mV.getCurrentModel() == false)
									 hpg.showModel("PoincareKlien",new Double( strZ ), (byte)0);
								else
									hpg.showModel("Gans",new Double( strZ ), (byte)0);


								 jTf1.setBackground(clrCorr );
								 jTf2.setBackground(clrCorr );
								 jTf3.setBackground(clrCorr );
						}
						else
						  {

							 if( strX.length()== 0)
								 jTf1.setBackground(clrIncorr );

							 if( strY.length()== 0)
								 jTf2.setBackground(clrIncorr );

							if( strZ.length()== 0)
								jTf3.setBackground(clrIncorr );

						}



		 }
		 catch( NumberFormatException nfe)
		 {

			  System.out.println(" Invalid Number");
			  jTf1.setBackground(clrIncorr );
			  jTf2.setBackground(clrIncorr );
			  jTf3.setBackground(clrIncorr );


		 }


    }

  }

}
