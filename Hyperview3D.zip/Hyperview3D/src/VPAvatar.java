package Hyperview3D;

import com.sun.j3d.utils.geometry.ColorCube;
import com.sun.j3d.utils.geometry.Cone;
import javax.media.j3d.Group.*;
import javax.media.j3d.*;
import javax.vecmath.Vector3d;
import com.sun.j3d.utils.picking.PickTool;
import javax.vecmath.AxisAngle4f;


/*

	This class reprents the cube which acts as the camera.
	The cube center = ViewPlatform center for the side view.
	Hence any transformations applied to the ViewPlatform
	should be applied to the cube and vice-versa.

*/

public class VPAvatar
{

		static TransformGroup tgg;
		BranchGroup bgg;

		 TransformGroup createBranchGroup( )
		 {

				//The 3 axes
				Axis axisMain = new Axis();
				TransformGroup tg = axisMain.createAxis(  1.0f , 30.0f , 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f  ) ;

				bgg = new BranchGroup();
				tgg = new TransformGroup();

				tgg.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
				tgg.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
				tgg.setCapability(TransformGroup.ENABLE_PICK_REPORTING);

				Transform3D t3D = new Transform3D();
				t3D.setTranslation( new Vector3d( 0.0 , 0.0 , -2.0) );
				t3D.setRotation( new AxisAngle4f( 1 , 1, 1 , (float)(Math.PI/6)));

				// the cube
				ColorCube cc = new ColorCube(0.20);

				 tgg.addChild(cc);
				 tgg.addChild(tg);
				 tgg.setTransform( t3D );



				return tgg;
		  }

		//Other classes call this
		void setTransform( Transform3D t3D )
		{

			tgg.setTransform( t3D );
		}

}