package Hyperview3D;

/*
 *	MultiUniverse.java 0.9 BETA 25.1.2004
 *
 * Copyright (c) 2004 Virtual Worlds Productions
 * Email: virtual_worlds@gmx.de
 *
 * This program is free software; you can redistribute it and/or modify  it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option) any
 * later version.
 *
 * Please contact virtual_worlds@gmx.de if you are interested in a source
 * package which is not licensed under the GPL
 *
 * This software is provided "AS IS," without a warranty of any kind. ALL
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING ANY
 * IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NON-INFRINGEMENT, ARE HEREBY EXCLUDED. VIRTUAL WORLDS PRODUCTIONS AND ITS
 * LICENSORS SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A
 * RESULT OF USING, MODIFYING OR DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES.
 * IN NO EVENT WILL VIRTUAL WORLDS PRODUCTIONS OR ITS LICENSORS BE LIABLE FOR
 * ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL,
 * CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS
 * OF THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE
 * SOFTWARE, EVEN IF VIRTUAL WORLDS PRODUCTIONS HAS BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES.
 *
 * This software is not designed or intended for use in on-line control of
 * aircraft, air traffic, aircraft navigation or aircraft communications; or in
 * the design, construction, operation or maintenance of any nuclear
 * facility. Licensee represents and warrants that it will not use or
 * redistribute the Software for such purposes.
 */

import com.sun.j3d.utils.universe.*;

import javax.media.j3d.*;

/****************************************************************************
 * This class sets up a user environment to quickly and easily get a Java 3D
 * program up and running with more than one View and Canvas3D. This class
 * bases on the SimpleUniverse and creates all the necessary objects on the
 * "view" side of the scene graph. Specifically, this class creates a locale,
 * ViewingPlatforms and Viewer objects (all with their default values).
 */
public class MultiUniverse extends VirtualUniverse
   {
  /**
   * Locale reference needed to create the "view" portion of the scene graph.
   */
   protected Locale          locale;

  /**
   * Viewer reference needed to create the "view" portion of the scene graph.
   */
   protected Viewer[]        viewer = null;

   int canvasCnt=0;


  /**************************************************************************
   * Creates a locale and prepares for the given number of transforms (and
   * therefore View, ViewPlatform and Canvas3D objects). This constructor
   * does not create the necessary views, to do that, use method
   * @see #createView(Canvas3D canvas)
   * @param numTransforms The number of View-Transforms and Canvas3D objects
   * which have to becontrolled by this object
   */
   public MultiUniverse(int numTransforms)
      {
      viewer = new Viewer[numTransforms];
      locale=new Locale(this);
      }




  /**************************************************************************
   * This method attaches the given Canvas3D object to the universe and
   * creates the required ViewPlatform and View object for it. This method
   * has to be called as often as much numTransforms habe been specified for
   * this methods constructor. The created Viewer- and View objects can be
   * accessed using the appropriate get-methods. The required number is
   * identically with the number of createView()-calls related to the view.
   * @param canvas the Canvas3D object which has to be attached to the
   *        Universe
   * @return the View object which was created for this Canvas3Ds view
   */
   public View createView(Canvas3D canvas)
      {
      ViewingPlatform vwp=new ViewingPlatform();
      viewer[canvasCnt]=new Viewer(canvas);
      viewer[canvasCnt].setViewingPlatform(vwp);
      locale.addBranchGraph(vwp);

      canvasCnt++;
      return viewer[canvasCnt-1].getView();
      }



  /****************************************************************************
   * Returns the Viewer object associated with this scene graph. MultiUniverse
   * creates a Viewer object for every attached Canvas3D.
   * @param num Specifies the number of the View which has to be returned. This
   *        number isequal to the number of createView()-calls which have been
   *        necessary to set up the View for the Canvas3D
   * @return The Viewer object associated with this scene graph
   */
   public Viewer getViewer(int num)
      {
      return viewer[num];
      }



  /***************************************************************************
   * Returns the ViewingPlatform object associated with this scene graph and
   * with the specified Canvas3D-number.
   * @param num specifies the number of the View which has to be returned. This
   *        number isequal to the number of createView()-calls which have been
   *        necessary to set up the View for the Canvas3D
   * @return The ViewingPlatform object of this scene graph.
   */
   public ViewingPlatform getViewingPlatform(int num)
      {
      return viewer[num].getViewingPlatform();
      }



  /***************************************************************************
   * Returns the Canvas3D object at the specified index associated with this
   * Java 3D Universe.
   * @param canvasNum The index of the Canvas3D object to retrieve. If there
   *        is no Canvas3D object for the given index, null is returned.
   * @param num The number of the View which has to be used to retrieve the
   *        Canvas3D
   * @return A reference to the Canvas3D object associated with the Viewer
   *        object.
   */
/* for j3d1.3.1   public Canvas3D getCanvas(int canvasNum,int num)
      {
      return viewer[num].getCanvas3D(canvasNum);
      }*/



  /****************************************************************************
   * Used to add Nodes to the geometry side (as opposed to the view side) of
   * the scene graph. This is a short cut to getting the Locale object and
   * calling that object's addBranchGraph() method.
   * @param bg the BranchGroup to attach to this Universe's Locale.
   */
   public void addBranchGraph(BranchGroup bg)
      {
      locale.addBranchGraph(bg);
      }



  /****************************************************************************
   * Cleanup memory use and reference by MultiUniverse. Typically it should be
   * invoked by the applet's destroy method.
   */
   public void cleanup()
      {
      for (int i=0; i<viewer.length; i++) if (viewer[i]!=null)
         {
// for j3d1.3.1         viewer[i].getView().removeAllCanvas3Ds();
         viewer[i].setViewingPlatform(null);
	      removeAllLocales();
	      // viewerMap cleanup here to prevent memory leak problem.
//		  for j3d1.3.1	      Viewer.clearViewerMap();
         }
      }



}
