package Hyperview3D;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


//This class allows the user to select between the 3 models ( via radio buttons)

class ModelSelectorPanel extends JPanel implements ActionListener
{

    Hyperboloid hpg;
    byte frameID;

   JRadioButton poincareButton = new JRadioButton("<html><b>P</b>oincare</html>");
   JRadioButton klienButton = new JRadioButton("<html><b>K</b>lein</html>");
   JRadioButton gansButton = new JRadioButton("<html><b>G</b>ans</html>");
   JRadioButton noneButton = new JRadioButton("");


    //Constructor. The frameID refers to either (0 - ModelFrame) or (1 - SideView Frame)
    ModelSelectorPanel( Hyperboloid hpg , byte frameID)
    {

			this.hpg = hpg;
			this.frameID = frameID;

		    poincareButton.setActionCommand("Poincare");
		    poincareButton.setSelected(false);
		    klienButton.setActionCommand("Klien");
		    gansButton.setActionCommand("Gans");

		    //Group the radio buttons.
		    ButtonGroup group = new ButtonGroup();
		    group.add(poincareButton);
		    group.add(klienButton);
		    group.add(gansButton);
			group.add(noneButton);

			add( poincareButton);
			add( klienButton);
			add( gansButton);

		    //Register a listener for the radio buttons.
		    poincareButton.addActionListener(this);
		    klienButton.addActionListener(this);
		    gansButton.addActionListener(this);

    }


//GUI callback
	public void actionPerformed(ActionEvent e)
	{

			String strModel = e.getActionCommand();

			//Reset user pos to 0,0
			if( frameID == 0 )
			 {
				 hpg.setObsX( 0.0);
				 hpg.setObsY( 0.0);
			}


			// If selected button is any of these call showModel() of 3D hyperboloid with given params to
			// see the model

			if( strModel.equals("Poincare"))
				  {
					   hpg.showModel("PoincareKlien",-1.0 , frameID);

				  }
			else if (strModel.equals("Klien"))
				 {
					  hpg.showModel("PoincareKlien",0.0,frameID);
				  }
			else if( strModel.equals("Gans"))
				 {
					 hpg.showModel("Gans", -1.0,frameID);
				  }
		}
}