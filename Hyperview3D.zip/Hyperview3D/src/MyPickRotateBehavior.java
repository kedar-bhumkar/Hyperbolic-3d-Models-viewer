package Hyperview3D;

import java.util.Enumeration;
import javax.media.j3d.*;
import javax.media.j3d.Group.*;
import com.sun.j3d.utils.behaviors.vp.OrbitBehavior;
import com.sun.j3d.utils.universe.*;
import com.sun.j3d.utils.picking.behaviors.PickRotateBehavior;
import com.sun.j3d.utils.picking.behaviors.PickingCallback;
import javax.vecmath.*;


/*

   This class is responsible for rotation on mouse drag
   Functionally it is similar to MyPickTranslateBehavior.
   See that class for more comments

*/


public class MyPickRotateBehavior extends PickRotateBehavior implements PickingCallback{

	TransformGroup tg;
	Hyperboloid hpg;
    PositionCoord posCoord;



	public MyPickRotateBehavior(BranchGroup bg , Canvas3D c3D , Bounds bounds , TransformGroup tg , Hyperboloid hpg , PositionCoord posCoord)
	{
			super( bg , c3D , bounds);
			this.tg = tg;
			this.hpg = hpg;
			this.posCoord = posCoord;


	}





public   void transformChanged(int type,  Transform3D t3d)
   {



		Transform3D t3D = new Transform3D();
		tg.getTransform(t3D);

		hpg.setVPTransform( (byte)0 , t3D );

        posCoord.findXYZ( t3D );




   }


public   void transformChanged(int type,  TransformGroup tgx)
   {

	   System.out.println( " Inside tC T3d " );


   }

}