------------------------------------------------------------------------------------
Copyright
------------------------------------------------------------------------------------

This program is free to use for any commerical or non-commercial purpose.


------------------------------------------------------------------------------------
Requirements
------------------------------------------------------------------------------------

J2SE 5.0 or higher.

Java 3d API 1.4 or higher.


------------------------------------------------------------------------------------
Running the Program( via command line )
------------------------------------------------------------------------------------

1) Copy the class files to a suitable location

2) cd Classes

3) To run the program use
    
   java Hyperview3D.Invoker ..\Images\EscherCircleLimitI.jpg
   
4) The folder Images contains all the images that can be used for texture mapping
   
------------------------------------------------------------------------------------
Compiling the Program
------------------------------------------------------------------------------------   
   
To compile the program use

   javac  src\*.java -d classes\
   
   
------------------------------------------------------------------------------------   
Basic Use
------------------------------------------------------------------------------------



1) When the program starts the viewer will be able to see a hyperboloid in 3D (side view). 
   Also he will be able to see the model view ( Klein, Poincare and Gans ).

2) Viewer will be able to navigate using mouse or entering texual co-ordinates  around  this model.
   To move the entire assembly ( hyperboloid and the camera ) select Orbitbehaviour.
   To move the camera alone select Camera Motion.

3) Special buttons are provided. One for each of the models Gans , Klien , 
   Poincare. On clicking them user will be able to get a view of the object in the corresponding    
   model. ( Each of these models are obtained by viewing the Weirstrass model from specific points ).    
   By selecting one model in Side View and another in MOdel view a comparison can be
   made between the 2 models at the same time.
   
4) Select the animation button to run the predefined animation. It is currently defined to show the 
   transition between Klein and poincare and back in a loop.
   
5) By selecting the wireframe button the texturemap is stripped  and original wireframe is displayed.
   Deslecting the button maps the last mapped texture back. 
   [Hint: Load the RedLine.jpg from the images folder on this wireframe to see how a line
   looks in different models.]
   
6) Using the file menu one can map any image on to this hyperboloid.   
   For best results in order to see the true differences in the models
   the texture images selected must be specially crafted. The given images 
   were used with permission from Dr Douglas Dunham's ( www.d.umn.edu/~ddunham ) 
   image creation tool for hyperbolic image viewing.
   
7) The properties.txt file located in the classes folder contains parameters which can be modified
   to change the displayed scenegraph.
   
8) More documentation coming soon!   